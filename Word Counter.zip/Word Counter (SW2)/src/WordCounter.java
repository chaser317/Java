
import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * This program reads in a text file and ouputs a corresponding html website
 * that lists each word in the text file alphabetically, along with the amount
 * of times each word occurs.
 *
 * @author Chase Markley (markley.124) (Latour 9:10)
 *
 */
public final class WordCounter {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private WordCounter() {
    }

    /*
     * Comparator to alphabetize the words included in a given mathematical
     * string text model
     */
    private static class stringSort implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.compareToIgnoreCase(o2);
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        String answer = "" + text.charAt(position);
        int index = position + 1;

        if (separators.contains(text.charAt(position))) {
            while (index < text.length()
                    && separators.contains(text.charAt(index))) {
                answer += text.charAt(index);
                index++;
            }
        } else if (!separators.contains(text.charAt(position))) {
            while (index < text.length()
                    && !separators.contains(text.charAt(index))) {
                answer += text.charAt(index);
                index++;
            }
        }

        return answer;
    }

    /*
     * Creates the html title (in the format "Words counted in  fileName") and
     * starts a 2 column table (one column titled "words" and one titled
     * "counts")
     *
     * @param out the channel to write the html code to
     *
     * @param fileName the name of the text file on the computer that the user
     * wishes to use
     *
     */
    private static void createHtml(SimpleWriter out, String fileName) {
        out.println("<html>");
        out.println("<head>");
        out.println("<title>" + "Words counted in " + fileName + "</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>" + "Words counted in " + fileName + "</h2>");
        out.println("<hr />");
        out.println("<table border=" + "\" 1 \"" + ">");
        out.println("<tr>");
        out.println("<th>" + "Word" + "</th>");
        out.println("<th>" + "Counts" + "</th>");
        out.println("</tr>");

    }

    /*
     * Reads in all words from a text file {@code WordsFile} and stores them in
     * a map{Map<String,Integer} with the keys as the words and the counts as
     * the values, ignoring separators and white space
     *
     * @param WordsFile the text file to have words and occurences of those
     * words counted
     *
     * @return a Map<String,Integer> with the keys as the unique words and
     * values as occurences of each word
     *
     * @requires WordsFile.length() > 0
     *
     * @ensures <pre> the Map<String, Integer> returned has the correct amount
     * of unique words in the text file and their respective counts
     */
    private static Map<String, Integer> readWords(String WordsFile) {

        /* Create map to store the words and occurences in */
        Map<String, Integer> words = new Map1L<>();

        /* Create set of separators for NWOS call */
        Set<Character> separators = new Set1L<>();
        separators.add(' ');
        separators.add(',');
        separators.add('-');
        separators.add('!');
        separators.add('?');
        separators.add('.');
        separators.add(':');
        separators.add(';');

        /*
         * Initialize the index to be used while reading in each line of the
         * text file (will be reset to 0 for every line)
         */
        int z = 0;

        /* Open stream to read input text file */
        SimpleReader read = new SimpleReader1L(WordsFile);

        /*
         * Logic for reading in words/occurences one by one using NWOS method
         * from SW1 to store in map
         */
        while (!read.atEOS()) {
            String temp = read.nextLine();
            z = 0;

            while (z < temp.length()) {

                String tempW = nextWordOrSeparator(temp, z, separators);

                if (tempW.contains(" ") || tempW.contains(",")
                        || tempW.contains("-") || tempW.contains("!")
                        || tempW.contains("?") || tempW.contains(".")
                        || tempW.contains(":") || tempW.contains(";")) {

                } else if (words.hasKey(tempW)) {
                    int tempV = words.value(tempW);
                    words.replaceValue(tempW, tempV + 1);

                } else {
                    words.add(tempW, 1);
                }

                z += tempW.length();
            }
        }

        /*
         * Close the input stream and return the map with the words and
         * occurences
         */
        read.close();
        return words;

    }

    /**
     * Creates a queue with all keys from a map, then alphabatizes the queue
     *
     * @param Map<String,String>
     *            the map to have its terms alphabatized into a queue
     *
     * @returns a queue with all of the keys from the map in alphabatized order
     *
     * @ensures Queue<String> is alphabatized
     *
     * @return a queue with all of the keys from a map in alphabetized order
     *
     * @requires all the keys in the map are those the user wishes to include in
     *           the glossary
     */
    private static Queue<String> queueSort(Map<String, Integer> keys) {

        Queue OrderedWords = new Queue1L<String>();

        /* Remove keys from map to put in a queue */
        for (Map.Pair<String, Integer> element : keys) {
            OrderedWords.enqueue(element.key());
        }

        /* Sort queue using comparator logic from stringSort */
        stringSort yuh = new stringSort();
        OrderedWords.sort(yuh);

        /* Return the alphabatized queue */
        return OrderedWords;

    }

    /*
     * Prints the keys and values from a map into an html table with 2 columns
     * respectively
     *
     * @param out the channel to write the html code to
     *
     *
     */
    private static void printWordCounts(SimpleWriter out,
            Map<String, Integer> wordsCounts, Queue<String> words) {

        for (String word : words) {
            out.println("<tr>");
            out.println("<td>" + word + "</td>");
            out.println("<td>" + wordsCounts.value(word) + "</td>");
            out.println("</tr>");
        }

    }

    /*
     * Prints the closing html tags
     *
     * @param out the channel to write the html code to
     *
     */
    private static void closeHtml(SimpleWriter out) {
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // Get text file from user to make a list of
        out.println(
                "Enter the name of an input text file to make a list of words and their occurences:");
        String data = in.nextLine();

        // Ask user for the name of the html output file
        out.println(
                "Enter the name you would like the output file to have with the .html extension:");
        String file = in.nextLine();

        // Open stream to file for html website info
        SimpleWriter fileOut = new SimpleWriter1L(file);

        // Output html title and start list of words
        createHtml(fileOut, data);

        // Create a map of the words and counts from the text file
        Map<String, Integer> Test = new Map1L<String, Integer>();
        Test = readWords(data);

        // Create Queue of the words in the map alphabetized
        Queue<String> wordsA = new Queue1L<>();
        wordsA = queueSort(Test);

        // Print words and counts to html file
        printWordCounts(fileOut, Test, wordsA);

        // Output html footer
        closeHtml(fileOut);

        // html site is now created :)

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
